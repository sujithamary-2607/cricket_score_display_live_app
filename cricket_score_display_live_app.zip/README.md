# Cricket Score Display (Live API version)

This Flask app attempts to fetch **live cricket data** from a public cricket API (CricAPI by default).
If you don't supply an API key or the provider call fails, the app falls back to a cached sample JSON so it still runs offline.

## How it fetches live data
- Default provider: **CricAPI** (https://api.cricapi.com). Example endpoint for matches:
  `https://api.cricapi.com/v1/currentMatches?apikey=YOUR_API_KEY`
  See CricAPI docs: https://www.cricapi.com/ and https://cricketdata.org/ for alternate free providers.
- If you prefer a different provider, edit `config.json` and set `API_PROVIDER` to the provider name and provide an `API_KEY`.
- For CricAPI you need to signup for an API key. Useful docs:
  - CricAPI / CricketData: https://www.cricapi.com/ and https://cricketdata.org/ .

## Setup (Windows)
1. (Optional) Create and activate a virtualenv:
   ```
   python -m venv venv
   .\venv\Scripts\activate
   ```
2. Install requirements:
   ```
   pip install -r requirements.txt
   ```
3. (Optional) Put your API key in `config.json` (edit the file) or set env var `CRIC_API_KEY`.
4. Run:
   ```
   python app.py
   ```
5. Open http://127.0.0.1:5000

## Notes
- Live API availability and exact JSON fields depend on the provider and API plan. This app attempts to normalize common fields across providers but you may need to adapt templates for provider-specific data.
- If you want me to wire it to a specific API (SportMonks, SportDevs, Roanuz, etc.) I can update the fetch logic — tell me which provider and I will include exact endpoints and example responses.
