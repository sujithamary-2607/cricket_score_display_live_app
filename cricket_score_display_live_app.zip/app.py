from flask import Flask, render_template, jsonify, request, redirect, url_for, flash
import requests, os, json, datetime

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET','dev_secret_key')

# Configuration: place API key and provider in config.json or environment variables
CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'config.json')
config = {}
if os.path.exists(CONFIG_PATH):
    with open(CONFIG_PATH) as f:
        config = json.load(f)

API_KEY = os.environ.get('CRIC_API_KEY') or config.get('API_KEY')  # user-provided API key
API_PROVIDER = config.get('API_PROVIDER','cricapi')  # 'cricapi' or 'cricketdata'
USE_CACHE = config.get('USE_CACHE', False)

SAMPLE_PATH = os.path.join(os.path.dirname(__file__), 'data', 'sample_matches.json')

def fetch_live_matches():
    # Try provider-specific endpoints. If no API_KEY or request fails, fallback to cached file.
    try:
        if API_PROVIDER == 'cricapi':
            if not API_KEY:
                raise Exception('No API key set for cricapi')
            url = f'https://api.cricapi.com/v1/currentMatches?apikey={API_KEY}&offset=0'
            r = requests.get(url, timeout=10)
            r.raise_for_status()
            data = r.json()
            # CricAPI v1 returns 'data' key with list of matches in many cases
            matches = data.get('data') or data.get('matches') or []
            return matches
        elif API_PROVIDER == 'cricketdata':
            # Example: cricketdata.org public endpoints may differ; this is a reasonable best-effort call
            url = 'https://cricketdata.org/api/matches'  # provider-specific; may require key
            params = {'api_key': API_KEY} if API_KEY else {}
            r = requests.get(url, params=params, timeout=10)
            r.raise_for_status()
            return r.json()
        else:
            # Unknown provider - raise to fallback
            raise Exception('Unknown API_PROVIDER')
    except Exception as e:
        app.logger.warning('Live fetch failed: %s', e)
        # Fallback to cached sample JSON
        try:
            with open(SAMPLE_PATH) as f:
                sample = json.load(f)
                return sample.get('matches', [])
        except Exception as e2:
            app.logger.error('Failed to load sample data: %s', e2)
            return []

@app.route('/')
def index():
    matches = []
    if not USE_CACHE:
        matches = fetch_live_matches()
    else:
        with open(SAMPLE_PATH) as f:
            sample = json.load(f)
            matches = sample.get('matches', [])
    # Normalize minimal fields for template
    normalized = []
    for m in matches:
        # many APIs use different keys; try to support common ones
        mid = m.get('id') or m.get('match_id') or m.get('unique_id') or m.get('id_str') or m.get('matchId') or None
        team1 = m.get('team-1') or m.get('team1') or (m.get('teams')[0] if m.get('teams') else None) or m.get('team_a')
        team2 = m.get('team-2') or m.get('team2') or (m.get('teams')[1] if m.get('teams') else None) or m.get('team_b')
        status = m.get('matchStarted') or m.get('status') or m.get('match_status') or m.get('statusText') or m.get('state') or ''
        score = m.get('score') or m.get('scorecard') or ''
        normalized.append({'id': mid, 'team1': team1, 'team2': team2, 'status': status, 'score': score})
    return render_template('index.html', matches=normalized)

@app.route('/match/<match_id>')
def match_detail(match_id):
    # Try to fetch detailed score for match
    detail = {}
    try:
        if API_PROVIDER == 'cricapi' and API_KEY:
            url = f'https://api.cricapi.com/v1/cricScore?apikey={API_KEY}&id={match_id}'
            r = requests.get(url, timeout=8); r.raise_for_status(); detail = r.json()
        else:
            # fallback: try matches list and find the id in cached sample
            with open(SAMPLE_PATH) as f:
                sample = json.load(f)
                for m in sample.get('matches', []):
                    if str(m.get('id')) == str(match_id) or str(m.get('unique_id')) == str(match_id):
                        detail = m
                        break
    except Exception as e:
        app.logger.warning('Detail fetch failed: %s', e)
        with open(SAMPLE_PATH) as f:
            sample = json.load(f)
            for m in sample.get('matches', []):
                if str(m.get('id')) == str(match_id) or str(m.get('unique_id')) == str(match_id):
                    detail = m
                    break
    return render_template('match.html', match=detail)

@app.route('/api/refresh')
def api_refresh():
    # Endpoint to manually trigger refresh (for admin). Just returns current live fetch result.
    matches = fetch_live_matches()
    return jsonify({'count': len(matches), 'matches': matches})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
